package Common.Genes;

public class RealGen extends Gen<Double>{
	public RealGen(double allele) {
		super(allele);
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return allele.toString();
	}

}
