package View;

public class main {
	public static void main(String[] args) {
		
		Mainframe frame= new Mainframe();
		
	}
}
