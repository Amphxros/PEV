/**
 * 
 */
/**
 * @author Amph
 *
 */
module P1G11 {
	requires java.desktop;
	requires jmathplot;
}